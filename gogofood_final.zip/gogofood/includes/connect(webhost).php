<?php
session_start();
$servername = "localhost";
$server_user = "id5572608_gogofood";
$server_pass = "GoGoFood";
$dbname = "id5572608_food";
$name = $_SESSION['name'];
$role = $_SESSION['role'];
$con = new mysqli($servername, $server_user, $server_pass, $dbname);
?>